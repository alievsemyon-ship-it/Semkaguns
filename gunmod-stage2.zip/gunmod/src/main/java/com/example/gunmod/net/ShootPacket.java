package com.example.gunmod.net;

import com.example.gunmod.GunItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record ShootPacket(boolean aiming) {
    public static void encode(ShootPacket p, FriendlyByteBuf b) {
        b.writeBoolean(p.aiming);
    }

    public static ShootPacket decode(FriendlyByteBuf b) {
        return new ShootPacket(b.readBoolean());
    }

    public static void handle(ShootPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer pl = ctx.get().getSender();
            if (pl != null && pl.getMainHandItem().getItem() instanceof GunItem gun) {
                gun.shoot(pl, p.aiming);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
