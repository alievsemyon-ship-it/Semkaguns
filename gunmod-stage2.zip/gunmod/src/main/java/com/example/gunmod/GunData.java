package com.example.gunmod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;

/** Обвесы оружия, хранятся в NBT предмета. */
public final class GunData {
    public static final int OPTIC = 0, GRIP = 1, UNDER = 2, MUZZLE = 3;
    public static final int MAX_POS = 4;

    public static final String[] SLOT_NAMES = {"Прицел", "Рукоять", "Подствольник", "Дульный модуль"};
    public static final String[][] VARIANTS = {
            {"Нет", "Коллиматор", "ELCAN 4x"},
            {"Нет", "Вертикальная", "Угловая"},
            {"Нет", "GL-40"},
            {"Нет", "Глушитель", "Компенсатор"}
    };
    private static final String[] KEYS = {"optic", "grip", "under", "muzzle"};

    private GunData() {}

    public static int get(ItemStack s, int slot) {
        CompoundTag t = s.getTag();
        return t == null ? 0 : t.getInt(KEYS[slot]);
    }

    public static void cycle(ItemStack s, int slot) {
        int v = (get(s, slot) + 1) % VARIANTS[slot].length;
        s.getOrCreateTag().putInt(KEYS[slot], v);
    }

    /** Положение прицела на планке: 0 (у дула) .. 4 (ближе к глазу). */
    public static int getPos(ItemStack s) {
        CompoundTag t = s.getTag();
        return t != null && t.contains("optic_pos") ? t.getInt("optic_pos") : 2;
    }

    public static void slide(ItemStack s, int delta) {
        int p = Math.max(0, Math.min(MAX_POS, getPos(s) + delta));
        s.getOrCreateTag().putInt("optic_pos", p);
    }
}
