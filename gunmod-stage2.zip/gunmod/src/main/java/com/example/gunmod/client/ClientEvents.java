package com.example.gunmod.client;

import com.example.gunmod.GunData;
import com.example.gunmod.GunItem;
import com.example.gunmod.GunMod;
import com.example.gunmod.net.AttachPacket;
import com.example.gunmod.net.GrenadePacket;
import com.example.gunmod.net.Net;
import com.example.gunmod.net.ShootPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GunMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClientEvents {
    private static int cd = 0;
    private static int grenadeCd = 0;
    private static boolean attachMode = false;
    private static int slot = 0;

    private static boolean holdingGun(Minecraft mc) {
        return mc.player != null && mc.player.getMainHandItem().getItem() instanceof GunItem;
    }

    private static ItemStack gun(Minecraft mc) {
        return mc.player.getMainHandItem();
    }

    public static boolean isAiming() {
        Minecraft mc = Minecraft.getInstance();
        return mc.screen == null && !attachMode && holdingGun(mc) && mc.options.keyUse.isDown();
    }

    /** Не даём ломать блоки / бить рукой, пока в руках оружие. */
    @SubscribeEvent
    public static void onInteract(InputEvent.InteractionKeyMappingTriggered e) {
        if (holdingGun(Minecraft.getInstance()) && (e.isAttack() || e.isUseItem())) {
            e.setCanceled(true);
            e.setSwingHand(false);
        }
    }

    /** В режиме обвесов колесо двигает прицел, а не переключает слот хотбара. */
    @SubscribeEvent
    public static void onScroll(InputEvent.MouseScrollingEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (!attachMode || mc.screen != null || !holdingGun(mc)) return;
        e.setCanceled(true);
        if (slot == GunData.OPTIC && GunData.get(gun(mc), GunData.OPTIC) != 0 && e.getScrollDelta() != 0) {
            Net.CHANNEL.sendToServer(new AttachPacket(1, slot, e.getScrollDelta() > 0 ? 1 : -1));
        }
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        boolean hasGun = holdingGun(mc);

        if (e.phase == TickEvent.Phase.START) {
            // START идёт до обработки клавиш ванилью, поэтому F можно перехватить
            while (KeyBinds.MODE.consumeClick()) {
                if (hasGun && mc.screen == null) {
                    attachMode = !attachMode;
                    slot = 0;
                }
            }
            if (!hasGun) attachMode = false;
            if (attachMode) {
                while (mc.options.keySwapOffhand.consumeClick()) { /* глушим обмен рук */ }
                while (KeyBinds.SLOT.consumeClick()) slot = (slot + 1) % GunData.SLOT_NAMES.length;
                while (KeyBinds.CHANGE.consumeClick()) Net.CHANNEL.sendToServer(new AttachPacket(0, slot, 0));
            } else {
                while (KeyBinds.SLOT.consumeClick()) { }
                while (KeyBinds.CHANGE.consumeClick()) { }
            }
            while (KeyBinds.GRENADE.consumeClick()) {
                if (hasGun && !attachMode && mc.screen == null && grenadeCd <= 0
                        && GunData.get(gun(mc), GunData.UNDER) == 1) {
                    grenadeCd = GunItem.GRENADE_COOLDOWN;
                    Net.CHANNEL.sendToServer(new GrenadePacket());
                    mc.player.setXRot(mc.player.getXRot() - 2.5f);
                }
            }
            return;
        }

        // END: автоматический огонь и отдача
        if (cd > 0) cd--;
        if (grenadeCd > 0) grenadeCd--;
        if (mc.screen == null && !attachMode && hasGun && mc.options.keyAttack.isDown() && cd <= 0) {
            cd = GunItem.COOLDOWN;
            boolean aim = isAiming();
            Net.CHANNEL.sendToServer(new ShootPacket(aim));

            ItemStack g = gun(mc);
            int grip = GunData.get(g, GunData.GRIP);
            int muzzle = GunData.get(g, GunData.MUZZLE);
            float v = aim ? 0.5f : 1.0f;
            float h = v;
            if (grip == 1) v *= 0.6f;
            else if (grip == 2) v *= 0.8f;
            if (muzzle == 2) { v *= 0.8f; h *= 0.5f; }
            mc.player.setXRot(mc.player.getXRot() - 0.9f * v);
            mc.player.setYRot(mc.player.getYRot() + (mc.player.getRandom().nextFloat() - 0.5f) * 0.8f * h);
        }
    }

    /** Зум при прицеливании зависит от установленного прицела. */
    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent e) {
        if (!isAiming()) return;
        int optic = GunData.get(gun(Minecraft.getInstance()), GunData.OPTIC);
        float f = optic == 2 ? 0.25f : optic == 1 ? 0.7f : 0.85f;
        e.setNewFovModifier(e.getFovModifier() * f);
    }

    @SubscribeEvent
    public static void onOverlay(RenderGuiOverlayEvent.Pre e) {
        if (e.getOverlay() != VanillaGuiOverlay.CROSSHAIR.type()) return;
        Minecraft mc = Minecraft.getInstance();
        if (!holdingGun(mc)) return;
        if (attachMode) { e.setCanceled(true); return; }
        if (!isAiming()) return;

        int optic = GunData.get(gun(mc), GunData.OPTIC);
        if (optic == 0) return; // механика: обычный прицел-крестик
        e.setCanceled(true);
        GuiGraphics g = e.getGuiGraphics();
        int w = e.getWindow().getGuiScaledWidth();
        int h = e.getWindow().getGuiScaledHeight();
        int cx = w / 2, cy = h / 2;

        if (optic == 1) { // коллиматор: красная точка
            g.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFF2020);
            return;
        }
        // ELCAN: чем ближе прицел к глазу (позиция больше), тем шире обзор
        int pos = GunData.getPos(gun(mc));
        int r = (int) (h * (0.28 + 0.05 * pos));
        int black = 0xFF000000;
        for (int y = 0; y < h; y++) {
            int half = r - Math.abs(y - cy);
            if (half <= 0) {
                g.fill(0, y, w, y + 1, black);
            } else {
                g.fill(0, y, cx - half, y + 1, black);
                g.fill(cx + half, y, w, y + 1, black);
            }
        }
        g.fill(cx - r, cy, cx + r, cy + 1, black);
        g.fill(cx, cy - r, cx + 1, cy + r, black);
    }

    /** Панель режима обвесов. */
    @SubscribeEvent
    public static void onHud(RenderGuiOverlayEvent.Post e) {
        if (e.getOverlay() != VanillaGuiOverlay.HOTBAR.type() || !attachMode) return;
        Minecraft mc = Minecraft.getInstance();
        if (!holdingGun(mc)) return;
        GuiGraphics g = e.getGuiGraphics();
        int x = 10;
        int y = e.getWindow().getGuiScaledHeight() / 2 - 40;
        ItemStack s = gun(mc);
        g.drawString(mc.font, "РЕЖИМ ОБВЕСОВ", x, y, 0xFFFFD040);
        y += 14;
        for (int i = 0; i < GunData.SLOT_NAMES.length; i++) {
            int v = GunData.get(s, i);
            boolean sel = i == slot;
            g.drawString(mc.font, (sel ? "> " : "  ") + GunData.SLOT_NAMES[i] + ": " + GunData.VARIANTS[i][v],
                    x, y, sel ? 0xFFFFFFFF : 0xFFAAAAAA);
            y += 11;
            if (i == GunData.OPTIC && v != 0) {
                int p = GunData.getPos(s);
                StringBuilder bar = new StringBuilder("    [");
                for (int k = 0; k <= GunData.MAX_POS; k++) bar.append(k == p ? '|' : '-');
                bar.append(']');
                g.drawString(mc.font, bar.toString(), x, y, sel ? 0xFF80FF80 : 0xFF608060);
                y += 11;
            }
        }
        y += 4;
        g.drawString(mc.font, "F - сменить   R - слот", x, y, 0xFF888888);
        g.drawString(mc.font, "Колесо - сдвиг прицела", x, y + 11, 0xFF888888);
        g.drawString(mc.font, "V - выход", x, y + 22, 0xFF888888);
    }
}
