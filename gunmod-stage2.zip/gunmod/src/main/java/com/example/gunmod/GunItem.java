package com.example.gunmod;

import com.example.gunmod.entity.GrenadeEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import javax.annotation.Nullable;

import java.util.List;

public class GunItem extends Item {
    public static final int COOLDOWN = 3;      // тиков между выстрелами (~400 в/мин)
    public static final double RANGE = 120;
    public static final float DAMAGE = 6.0f;
    public static final int GRENADE_COOLDOWN = 40;

    public GunItem(Properties props) {
        super(props);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        for (int i = 0; i < GunData.SLOT_NAMES.length; i++) {
            int v = GunData.get(stack, i);
            if (v != 0) {
                tip.add(Component.literal(GunData.SLOT_NAMES[i] + ": " + GunData.VARIANTS[i][v]).withStyle(ChatFormatting.GRAY));
            }
        }
        tip.add(Component.literal("V - режим обвесов, G - подствольник").withStyle(ChatFormatting.DARK_GRAY));
    }

    /** Вызывается на сервере из пакета стрельбы. */
    public void shoot(ServerPlayer player, boolean aiming) {
        if (player.getCooldowns().isOnCooldown(this)) return;
        ServerLevel level = player.serverLevel();

        if (!player.getAbilities().instabuild && !consumeAmmo(player)) {
            level.playSound(null, player.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 0.8f, 1.5f);
            player.getCooldowns().addCooldown(this, 10);
            return;
        }
        player.getCooldowns().addCooldown(this, COOLDOWN);

        ItemStack gun = player.getMainHandItem();
        int muzzle = GunData.get(gun, GunData.MUZZLE);
        int grip = GunData.get(gun, GunData.GRIP);
        boolean suppressed = muzzle == 1;

        Vec3 start = player.getEyePosition();
        Vec3 dir = player.getLookAngle();
        double spread = aiming ? 0.003 : 0.02;
        if (grip == 2) spread *= 0.8;
        RandomSource r = player.getRandom();
        dir = dir.add((r.nextDouble() - 0.5) * 2 * spread, (r.nextDouble() - 0.5) * 2 * spread, (r.nextDouble() - 0.5) * 2 * spread).normalize();
        Vec3 end = start.add(dir.scale(RANGE));

        BlockHitResult bhit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 limit = bhit.getType() != HitResult.Type.MISS ? bhit.getLocation() : end;

        AABB box = player.getBoundingBox().expandTowards(dir.scale(RANGE)).inflate(1.0);
        EntityHitResult ehit = ProjectileUtil.getEntityHitResult(level, player, start, limit, box,
                e -> !e.isSpectator() && e.isPickable());

        Vec3 impact = limit;
        if (ehit != null) {
            impact = ehit.getLocation();
            ehit.getEntity().invulnerableTime = 0;
            ehit.getEntity().hurt(level.damageSources().playerAttack(player), suppressed ? DAMAGE * 0.9f : DAMAGE);
        }
        if (bhit.getType() != HitResult.Type.MISS || ehit != null) {
            level.sendParticles(ParticleTypes.CRIT, impact.x, impact.y, impact.z, 4, 0.05, 0.05, 0.05, 0.1);
        }

        if (!suppressed) {
            Vec3 muzzlePos = start.add(dir.scale(1.0));
            level.sendParticles(ParticleTypes.SMOKE, muzzlePos.x, muzzlePos.y - 0.15, muzzlePos.z, 3, 0.03, 0.03, 0.03, 0.01);
        }
        level.playSound(null, player.blockPosition(), SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS,
                suppressed ? 0.3f : 1.2f, suppressed ? 2.0f : 1.6f);
    }

    /** Выстрел из подствольного гранатомёта GL-40. */
    public void fireGrenade(ServerPlayer player) {
        ItemStack gun = player.getMainHandItem();
        if (GunData.get(gun, GunData.UNDER) != 1) return;
        Item grenade = ModItems.GRENADE.get();
        if (player.getCooldowns().isOnCooldown(grenade)) return;
        ServerLevel level = player.serverLevel();

        if (!player.getAbilities().instabuild) {
            ItemStack found = ItemStack.EMPTY;
            for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
                ItemStack s = player.getInventory().getItem(i);
                if (s.is(grenade)) { found = s; break; }
            }
            if (found.isEmpty()) {
                level.playSound(null, player.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 0.8f, 1.2f);
                player.getCooldowns().addCooldown(grenade, 10);
                return;
            }
            found.shrink(1);
        }

        GrenadeEntity g = new GrenadeEntity(level, player);
        g.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0f, 2.0f, 0.5f);
        level.addFreshEntity(g);
        player.getCooldowns().addCooldown(grenade, GRENADE_COOLDOWN);
        level.playSound(null, player.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.4f, 1.8f);
    }

    private boolean consumeAmmo(ServerPlayer player) {
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s.is(ModItems.BULLET.get())) {
                s.shrink(1);
                return true;
            }
        }
        return false;
    }
}
