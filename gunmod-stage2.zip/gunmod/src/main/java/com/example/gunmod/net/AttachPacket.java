package com.example.gunmod.net;

import com.example.gunmod.GunData;
import com.example.gunmod.GunItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** op 0: сменить вариант в слоте; op 1: сдвинуть прицел на value (+1/-1). */
public record AttachPacket(int op, int slot, int value) {
    public static void encode(AttachPacket p, FriendlyByteBuf b) {
        b.writeVarInt(p.op);
        b.writeVarInt(p.slot);
        b.writeVarInt(p.value + 8);
    }

    public static AttachPacket decode(FriendlyByteBuf b) {
        return new AttachPacket(b.readVarInt(), b.readVarInt(), b.readVarInt() - 8);
    }

    public static void handle(AttachPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer pl = ctx.get().getSender();
            if (pl == null) return;
            ItemStack s = pl.getMainHandItem();
            if (!(s.getItem() instanceof GunItem)) return;
            if (p.op == 0 && p.slot >= 0 && p.slot < GunData.SLOT_NAMES.length) {
                GunData.cycle(s, p.slot);
            } else if (p.op == 1) {
                GunData.slide(s, Integer.signum(p.value));
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
