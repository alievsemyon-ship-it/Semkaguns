package com.example.gunmod.client;

import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public class KeyBinds {
    public static final String CAT = "key.categories.gunmod";
    public static final KeyMapping MODE = new KeyMapping("key.gunmod.mode", GLFW.GLFW_KEY_V, CAT);
    public static final KeyMapping SLOT = new KeyMapping("key.gunmod.slot", GLFW.GLFW_KEY_R, CAT);
    public static final KeyMapping CHANGE = new KeyMapping("key.gunmod.change", GLFW.GLFW_KEY_F, CAT);
    public static final KeyMapping GRENADE = new KeyMapping("key.gunmod.grenade", GLFW.GLFW_KEY_G, CAT);
}
