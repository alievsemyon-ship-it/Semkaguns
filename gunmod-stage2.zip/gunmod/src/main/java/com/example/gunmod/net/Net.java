package com.example.gunmod.net;

import com.example.gunmod.GunMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class Net {
    private static final String V = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(GunMod.MODID, "main"), () -> V, V::equals, V::equals);

    public static void register() {
        CHANNEL.registerMessage(0, ShootPacket.class, ShootPacket::encode, ShootPacket::decode, ShootPacket::handle);
        CHANNEL.registerMessage(1, AttachPacket.class, AttachPacket::encode, AttachPacket::decode, AttachPacket::handle);
        CHANNEL.registerMessage(2, GrenadePacket.class, GrenadePacket::encode, GrenadePacket::decode, GrenadePacket::handle);
    }
}
