package com.example.gunmod.net;

import com.example.gunmod.GunItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record GrenadePacket() {
    public static void encode(GrenadePacket p, FriendlyByteBuf b) {}

    public static GrenadePacket decode(FriendlyByteBuf b) {
        return new GrenadePacket();
    }

    public static void handle(GrenadePacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer pl = ctx.get().getSender();
            if (pl != null && pl.getMainHandItem().getItem() instanceof GunItem gun) {
                gun.fireGrenade(pl);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
